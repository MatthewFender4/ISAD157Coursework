﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using ISAD157SampleCode.Models;
using ISAD157SampleCode.Data;
using MySql.Data.MySqlClient;
namespace ISAD157SampleCode
{
    public partial class Form1 : Form
    {
        List<PersonEducation> prevEducation = new List<PersonEducation>();
        List<PersonWorkplaces> prevWork = new List<PersonWorkplaces>();
        List<Messages> allMessages = new List<Messages>();
        List<Person> allPersons = new List<Person>();
        PersonDetails usersDetails = new PersonDetails();
        List<string> sendToListNames = new List<string>();

        int tempID;

        string tempIDString;
        string tempFirstName;
        string tempLastName;
        string tempHomeTown;
        string tempCurrentCity;
        string tempGender;
        string tempRelationship;






        string connectionString = "SERVER=" + DBConnect.SERVER + ";" +
                              "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                              DBConnect.USER_NAME + ";" + "PASSWORD=" +
                              DBConnect.PASSWORD + ";" + "SslMode=" +
                              DBConnect.SslMode + ";";

        MySqlConnection connection;

        string query;

        DataChecks dataChecks = new DataChecks(); // used for checking which field have been included in a search

        public Form1()
        {
            InitializeComponent();

            //connect to the DB
            connection = new MySqlConnection(connectionString);
            connection.Open();

            dataGridViewUserDetails.Visible = false;
            tabControl1.SelectedIndexChanged += new EventHandler(tabControl1_SelectedIndexChanged);
    
        }


        private void FillUsertable()
        {
            string query = "SELECT * FROM user";

            MySqlCommand cmd = new MySqlCommand(query, connection);

            MySqlDataAdapter sqlDA = new MySqlDataAdapter(cmd);
            DataTable userDataTable = new DataTable();
            sqlDA.Fill(userDataTable);

            dataGridViewUsers.DataSource = userDataTable;
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {  
            //confirm this logs in and can access the data

            tabControl1.SelectedTab = UserData;
            FillUsertable();
            

        }


        private void dataFieldsCheck()
        {
            //set all to false;

            dataChecks.SetAllFalse();

            if (UserIDtextbox.Text != "") dataChecks.UserId = true;
            if (FirstNameTextbox.Text != "") dataChecks.firstName = true;
            if (LastNametextbox.Text != "") dataChecks.lastName = true;
            if (HomeTownTextbox.Text != "") dataChecks.homeTown = true;
            if (CurrentCityTextbox.Text != "") dataChecks.currentCity = true;
            if (GenderTextbox.Text != "") dataChecks.gender = true;
            if (RelationshipTextbox.Text != "") dataChecks.relationship = true;
        }

        private void SelectAUser() 
        {
            int tempID; //used in search

            dataFieldsCheck();
            if (!dataChecks.UserId)
            {
                MessageBox.Show("Please enter a UserId Value", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            else
            {
                tempID = Int32.Parse(UserIDtextbox.Text);
                query = "SELECT * FROM user WHERE user_ID = " + tempID + ";";
            }

            MySqlConnection connection = new MySqlConnection(connectionString);

            connection.Open();

            MySqlCommand cmd = new MySqlCommand(query, connection);

            MySqlDataAdapter sqlDA = new MySqlDataAdapter(cmd);
            DataTable userDataTable = new DataTable();
            sqlDA.Fill(userDataTable);

            dataGridViewUsers.DataSource = userDataTable;

            int numRows = userDataTable.Rows.Count;

            if (numRows == 1)
            {
                //now get the userID if there is just 1
                int tempInt = (int)userDataTable.Rows[0]["user_id"];
                UserIDtextbox.Text = tempInt.ToString();
                FirstNameTextbox.Text = (string)userDataTable.Rows[0]["first_name"];
                LastNametextbox.Text = (string)userDataTable.Rows[0]["last_name"];

                //now get the rest of the user details
                query = "SELECT * FROM user_details WHERE user_id = " + tempID + ";";

                cmd = new MySqlCommand(query, connection);

                sqlDA = new MySqlDataAdapter(cmd);
                DataTable userDetailTable = new DataTable();
                sqlDA.Fill(userDetailTable);

                dataGridViewUserDetails.DataSource = userDetailTable;

                numRows = userDetailTable.Rows.Count;


                if (numRows == 1)
                {
                    HomeTownTextbox.Text = (string)userDetailTable.Rows[0]["home_town"];
                    GenderTextbox.Text = (string)userDetailTable.Rows[0]["gender"];
                    RelationshipTextbox.Text = (string)userDetailTable.Rows[0]["relationship_status"];
                    CurrentCityTextbox.Text = (string)userDetailTable.Rows[0]["current_town"];
                }
                else
                {
                    MessageBox.Show("Data error more than 1 set of user details", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }


                if (numRows == 1)
                { //get the workplaces

                    //  query = "SELECT workplace_name, FROM workplace_names";

                    query = "SELECT workplace_name, start_date, end_date FROM workplaces JOIN workplace_names ON workplaces.workplace_id = workplace_names.workplace_id WHERE workplaces.user_id = " + tempID + ";";

                    cmd = new MySqlCommand(query, connection);
                    sqlDA = new MySqlDataAdapter(cmd);
                    DataTable WPDataTable = new DataTable();
                    sqlDA.Fill(WPDataTable);
                    dataGridViewWP.DataSource = WPDataTable;
                }

                if (numRows == 1)
                { //get the schools

                    //    query = "SELECT * FROM schools";

                    query = "SELECT school_name, start_date, end_date FROM schools JOIN school_names ON schools.school_id = school_names.school_id WHERE schools.user_id = " + tempID + ";";

                    cmd = new MySqlCommand(query, connection);
                    sqlDA = new MySqlDataAdapter(cmd);
                    DataTable SchoolsDataTable = new DataTable();
                    sqlDA.Fill(SchoolsDataTable);
                    dataGridViewSchools.DataSource = SchoolsDataTable;
                }

                if (numRows == 1)
                { //get the friends

                    query = "SELECT first_name, last_name FROM friends JOIN user ON friends.user2_id = user.user_id WHERE friends.user1_id = " + tempID + ";";

                    cmd = new MySqlCommand(query, connection);
                    sqlDA = new MySqlDataAdapter(cmd);
                    DataTable FriendsDataTable = new DataTable();
                    sqlDA.Fill(FriendsDataTable);
                    dataGridViewFriends.DataSource = FriendsDataTable;
                }

                if (numRows == 1)
                { //get the messages

                    // query = "SELECT * FROM messages";

                    query = "SELECT message_text, first_name, last_name FROM messages JOIN user ON messages.sender_id = user.user_id WHERE messages.user_id = " + tempID + ";";

                    cmd = new MySqlCommand(query, connection);
                    sqlDA = new MySqlDataAdapter(cmd);
                    DataTable MessagesDataTable = new DataTable();
                    sqlDA.Fill(MessagesDataTable);
                    dataGridViewMessages.DataSource = MessagesDataTable;
                }

            }

            }

        private void SelectUserBtn_Click(object sender, EventArgs e)
        {
            SelectAUser(); 
             
        }

        private string Quotes(string word)
        { //adds single quotes to enable the SQL query
            word = "'" + word + "'";
            return word;
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        { // search for all users with a certain data field
          // if first and last names are included it searches on both

            bool searchComplete = false;

            dataFieldsCheck();

            if (dataChecks.firstName == true && dataChecks.lastName == true)
            {
                string fn = Quotes(FirstNameTextbox.Text);
                string ln = Quotes(LastNametextbox.Text);
                query = "SELECT * FROM user WHERE first_name = " + fn + " AND last_name = " + ln + ";";
                searchComplete = true;
            }
            else if (dataChecks.firstName)
            {
                string fn = Quotes(FirstNameTextbox.Text);
                query = "SELECT * FROM user WHERE first_name = " + fn;
                searchComplete = true;
            }
            else if (dataChecks.lastName)
            {
                string ln = Quotes(LastNametextbox.Text);
                query = "SELECT * FROM user WHERE last_name = " + ln;
                searchComplete = true;
            }

            if (!searchComplete)
            {
                if (dataChecks.homeTown)
                {
                    string ht = Quotes(HomeTownTextbox.Text);
                    query = "SELECT * FROM user_detail WHERE home_town = " + ht;
                    searchComplete = true;
                }
            }


            if (!searchComplete)
            {
                if (dataChecks.currentCity)
                {
                    string ht = Quotes(CurrentCityTextbox.Text);
                    query = "SELECT * FROM user_detail WHERE home_town = " + ht;
                    searchComplete = true;
                }
            }

            if (! searchComplete )
            {
                MessageBox.Show("Sorry no search available for gender or relationship", "Search not Available", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MySqlCommand cmd = new MySqlCommand(query, connection);

                MySqlDataAdapter sqlDA = new MySqlDataAdapter(cmd);
                DataTable userDataTable = new DataTable();
                sqlDA.Fill(userDataTable);

                dataGridViewUsers.DataSource = userDataTable;
            }
        }

        private void LoadDataTablesBtn1_Click(object sender, EventArgs e)
        {
            //load all 4 datatables

            query = "SELECT * FROM user";

            MySqlCommand cmd = new MySqlCommand(query, connection);

            MySqlDataAdapter sqlDA = new MySqlDataAdapter(cmd);
            DataTable userDataTable = new DataTable();
            sqlDA.Fill(userDataTable);

            dataGridViewDBUsers.DataSource = userDataTable;

            query = "SELECT * FROM user_details";

            cmd = new MySqlCommand(query, connection);

            sqlDA = new MySqlDataAdapter(cmd);
            DataTable userDetailDataTable = new DataTable();
            sqlDA.Fill(userDetailDataTable);

            dataGridViewDBUserDetail.DataSource = userDetailDataTable;

            query = "SELECT * FROM friends";

            cmd = new MySqlCommand(query, connection);

            sqlDA = new MySqlDataAdapter(cmd);
            DataTable friendsDataTable = new DataTable();
            sqlDA.Fill(friendsDataTable);

            dataGridViewDBFriends.DataSource = userDetailDataTable;

            query = "SELECT * FROM messages";

            cmd = new MySqlCommand(query, connection);

            sqlDA = new MySqlDataAdapter(cmd);
            DataTable messagesDataTable = new DataTable();
            sqlDA.Fill(messagesDataTable);

            dataGridViewDBMessages.DataSource = messagesDataTable;

        }

        private void LoadDataTablesBtn2_Click(object sender, EventArgs e)
        {
            //load all 4 datatables

            query = "SELECT * FROM schools";

            MySqlCommand cmd = new MySqlCommand(query, connection);

            MySqlDataAdapter sqlDA = new MySqlDataAdapter(cmd);
            DataTable schoolsDataTable = new DataTable();
            sqlDA.Fill(schoolsDataTable);

            dataGridViewDBSchools.DataSource = schoolsDataTable;

            query = "SELECT * FROM school_names";

            cmd = new MySqlCommand(query, connection);

            sqlDA = new MySqlDataAdapter(cmd);
            DataTable schoolNamesDataTable = new DataTable();
            sqlDA.Fill(schoolNamesDataTable);

            dataGridViewDBSchoolNames.DataSource = schoolNamesDataTable;

            query = "SELECT * FROM workplaces";

            cmd = new MySqlCommand(query, connection);

            sqlDA = new MySqlDataAdapter(cmd);
            DataTable workplacesDataTable = new DataTable();
            sqlDA.Fill(workplacesDataTable);

            dataGridViewDBWorkplaces.DataSource = workplacesDataTable;

            query = "SELECT * FROM workplace_names";

            cmd = new MySqlCommand(query, connection);

            sqlDA = new MySqlDataAdapter(cmd);
            DataTable workplaceNamesDataTable = new DataTable();
            sqlDA.Fill(workplaceNamesDataTable);

            dataGridViewDBWorkplaceNames.DataSource = workplaceNamesDataTable;

        }

        private void ClearUserScreenData() 
        {
            //clears the tables and fields on the userDB screen


            UserIDtextbox.Text = "";
            FirstNameTextbox.Text = "";
            LastNametextbox.Text = "";
            HomeTownTextbox.Text = "";
            GenderTextbox.Text = "";
            RelationshipTextbox.Text = "";
            CurrentCityTextbox.Text = "";

            dataGridViewUsers.Columns.Clear();
            dataGridViewSchools.Columns.Clear();
            dataGridViewWP.Columns.Clear();
            dataGridViewFriends.Columns.Clear();
            dataGridViewMessages.Columns.Clear();

        }


        private void ClearAllBtn_Click(object sender, EventArgs e)
        {
            ClearUserScreenData();
        }

        private void LoadAllUserDataBtn_Click(object sender, EventArgs e)
        {
           ClearUserScreenData();
           FillUsertable();


        }

        private void AddUserBtn_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
            // change to add new user page
        }

        private void AddNewUserBtn_Click(object sender, EventArgs e)
        {
            // give random user ID above 500

            var rnd = new Random();
            int thisID = rnd.Next(5100, 9999);

            if(FirstNameText.Text !="" && LastNameText.Text != "")
            {
                // there can be duplicate names but they will have unique userIds

                string fn = Quotes(FirstNameText.Text);
                string ln = Quotes(LastNameText.Text);

                if (HomeTownText.Text == "") HomeTownText.Text = "unknown";
                string ht = Quotes(HomeTownText.Text);
                if (CurrentCityText.Text == "") CurrentCityText.Text = "unknown";
                string cc = Quotes(CurrentCityText.Text);
                if (GenderText.Text == "") GenderText.Text = "unknown";
                string gt = Quotes(GenderText.Text);
                if (RelationshipText.Text == "") RelationshipText.Text = "unknown";
                string rt = Quotes(RelationshipText.Text);

                string  mySQL = "INSERT INTO user (user_id, first_name, last_name) VALUES ( " + thisID  + ","+ fn +", " + ln + ")" + ";";
                
                MySqlCommand cmd = new MySqlCommand(mySQL,connection);
                cmd.ExecuteNonQuery();

               mySQL = "INSERT INTO user_details (user_id, home_town, gender, relationship_status, current_town) VALUES ( " + thisID  +"," + ht + ", "+ cc +", " +gt+","+rt+")" + ";";

               cmd = new MySqlCommand(mySQL, connection);
               cmd.ExecuteNonQuery();
               MessageBox.Show("New user added successfully", "Not Added", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("You must provide a first name and last name to create a new user", "Not Added", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

           
        }

        private void DeleteUserBtn_Click(object sender, EventArgs e)
        {
            if (UserIDtextbox.Text == "")
            {
                MessageBox.Show("You must provide userID", "No user ID!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {  //fill in the names
               
                SelectAUser();
                tempID = Int32.Parse(UserIDtextbox.Text);

               DialogResult result =  MessageBox.Show("Are you sure you want to delete this user", "Cannot be undone", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes )
                {
                    string mySQL = "DELETE FROM user WHERE user_ID =" + tempID + ";";
                    MySqlCommand cmd = new MySqlCommand(mySQL, connection);
                    cmd.ExecuteNonQuery();
                    mySQL = "DELETE FROM user_details WHERE user_ID =" + tempID + ";";
                    cmd = new MySqlCommand(mySQL, connection);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User was Deleted", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Not Deleted", "Delete not confirmed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                };

                ClearUserScreenData();
                FillUsertable();
               

            }
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {

            if (UserIDtextbox.Text == "")
            {
                MessageBox.Show("User ID Required", "Please insert user ID and press Select User ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to EDIT this user", "Cannot be undone", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                //retain the data in temp
  

                tempIDString = UserIDtextbox.Text;
                tempFirstName = FirstNameTextbox.Text;
                tempLastName = LastNametextbox.Text;
                tempHomeTown = HomeTownTextbox.Text;
                tempCurrentCity = CurrentCityTextbox.Text;
                tempGender = GenderTextbox.Text;
                tempRelationship = RelationshipTextbox.Text;

                tabControl1.SelectedTab = tabPage2;


                UserIDLabel.Text = tempIDString;
                EditFirstName.Text = tempFirstName;
                EditLastName.Text = tempLastName;
                EditHomeTown.Text = tempHomeTown;
                EditCurrentCity.Text = tempCurrentCity;
                EditGender.Text = tempGender;
                EditRelationship.Text = tempRelationship;
               
            }

        }

        private void SubmitEdit_Click(object sender, EventArgs e)
        {

            //id is unchanged in tempIDString

            int theID = Int32.Parse(tempIDString);

            string fn = Quotes(EditFirstName.Text);
            string ln = Quotes(EditLastName.Text);
            if (EditHomeTown.Text == "") HomeTownText.Text = "unknown";
            string ht = Quotes(HomeTownText.Text);
            if (EditCurrentCity.Text == "") CurrentCityText.Text = "unknown";
            string cc = Quotes(CurrentCityText.Text);
            if (EditGender.Text == "") GenderText.Text = "unknown";
            string gt = Quotes(GenderText.Text);
            if (EditRelationship.Text == "") RelationshipText.Text = "unknown";
            string rt = Quotes(RelationshipText.Text);

            string mySQL = "UPDATE user SET first_name = " + fn + "WHERE user_id = " + theID + ";";
            MySqlCommand cmd = new MySqlCommand(mySQL, connection);
            cmd.ExecuteNonQuery();

            mySQL = "UPDATE user SET last_name = " + ln + "WHERE user_id = " + theID + ";";
            cmd = new MySqlCommand(mySQL, connection);
            cmd.ExecuteNonQuery();


            mySQL = "UPDATE user_details SET home_town = " + ht + "WHERE user_id = " + theID + ";";
            cmd = new MySqlCommand(mySQL, connection);
            cmd.ExecuteNonQuery();

            mySQL = "UPDATE user_details SET current_town = " + cc + "WHERE user_id = " + theID + ";";
            cmd = new MySqlCommand(mySQL, connection);
            cmd.ExecuteNonQuery();

            mySQL = "UPDATE user_details SET gender = " + gt + "WHERE user_id = " + theID + ";";
            cmd = new MySqlCommand(mySQL, connection);
            cmd.ExecuteNonQuery();

            mySQL = "UPDATE user_details SET relationship_status = " + rt + "WHERE user_id = " + theID + ";";
            cmd = new MySqlCommand(mySQL, connection);
            cmd.ExecuteNonQuery();

            MessageBox.Show("User data was update", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }


        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e )
        {
           
        }



        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

  

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

      

        private void label15_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

       

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click_2(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void SentMessagesList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       

        private void button3_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click_1(object sender, EventArgs e)
        {

        }


        
    }
}
