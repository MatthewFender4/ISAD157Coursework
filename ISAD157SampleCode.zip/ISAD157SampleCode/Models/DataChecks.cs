﻿using Org.BouncyCastle.Bcpg;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISAD157SampleCode.Models
{
   public class DataChecks
    {
      public bool UserId { get; set; }
      public bool firstName { get; set; }
      public  bool lastName { get; set; }
      public  bool homeTown { get; set; }
      public  bool currentCity { get; set; }
      public  bool gender { get; set; }
      public bool relationship { get; set; }


     public void SetAllFalse()
      {
            UserId = false;
            firstName = false;
            lastName= false;
            homeTown = false;
            currentCity = false;
            gender = false;
            relationship = false;
            
        }



    }
}
