﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAD157SampleCode.Models
{
    public class Messages
    {
        public int MessageID { get; set; }
        public int SenderID { get; set; }
        public int ReceiverID { get; set; }
        public DateTime dt { get; set; }
        public string MessageText { get; set; }

       public Messages CreateNewMessage(int sendID, int receiveID, string theMessage)
        {
            DateTime localTime = new DateTime();
            localTime = DateTime.Now;

            Messages message = new Messages()
            {
                MessageID = 1000, SenderID = sendID, ReceiverID = receiveID, dt = localTime, MessageText = theMessage
            };

            return message;

        }

    }
}
