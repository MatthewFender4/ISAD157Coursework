﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAD157SampleCode.Models
{
    public class PersonDetails
    {
        public int userID { get; set; }
        public string homeTown { get; set; }
        public string currentCity{ get; set; }
        public string gender { get; set; }
        public string relationship { get; set; }


    }
}
