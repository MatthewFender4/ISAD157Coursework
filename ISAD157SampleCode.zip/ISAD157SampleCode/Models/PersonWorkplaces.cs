﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAD157SampleCode.Models
{
   public class PersonWorkplaces
    {
        public int userID { get; set; }
        public string placeName { get; set; }
        public DateTime dateStarted { get; set; }
        public DateTime dateFinished { get; set; }
    }
}
