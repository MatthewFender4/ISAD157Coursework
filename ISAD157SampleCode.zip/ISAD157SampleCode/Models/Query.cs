﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAD157SampleCode.Models
{
   public class Query
    {
        public string queryName { get; set; }
        public string theQuery { get; set; }
        public int columns { get; set; }  //num columns returned by the query

    }
}
