﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ISAD157SampleCode.Models;
using ISAD157SampleCode.Data;
using MySql.Data.MySqlClient;

namespace ISAD157SampleCode
{
    public class DataManager
    {
        public static List<Query> allQueries = new List<Query>()
        {
            new Query{queryName="getAllUsers", theQuery="SELECT * FROM ??????"  },
            new Query{queryName="getAllFriends", theQuery="SELECT * FROM ??????"  },
            new Query{queryName="getAllSchools", theQuery="SELECT * FROM ??????"  },
            new Query{queryName="getAllWorkPlaces", theQuery="SELECT * FROM ??????"  },
            new Query{queryName="getAllMessages", theQuery="SELECT * FROM ??????"  },
            new Query{queryName="getPersonDetails", theQuery="SELECT * FROM ??????"  },
            new Query{queryName="getMessagesFrom", theQuery="SELECT * FROM ??????"  },
            new Query{queryName="getMessagesSent", theQuery="SELECT * FROM ??????"  },
            new Query{queryName="AddNewUser", theQuery="INSERT INTO ????  (??, ??, ??) VALUES('a','b','c'}" },
            new Query{queryName="AddNewUserDetails", theQuery="INSERT INTO ????  (??, ??, ??) VALUES('a','b','c'}" },
            new Query{queryName="DeleteUser", theQuery="DELETE FROM ???? WHERE ID = ????"  },
            new Query{queryName="DeleteFriend", theQuery="DELETE FROM ???? WHERE ID = ????"  },
            new Query{queryName="UpdateUser", theQuery="UPDATE tableName SET ab = newValue WHERE ID=??"  },


        };

        public static void OpenDB()
        {
            string connectionString = "SERVER=" + DBConnect.SERVER + ";" +
                               "DATABASE=" + DBConnect.DATABASE_NAME + ";" + "UID=" +
                               DBConnect.USER_NAME + ";" + "PASSWORD=" +
                               DBConnect.PASSWORD + ";" + "SslMode=" +
                               DBConnect.SslMode + ";";

            MySqlConnection connection = new MySqlConnection(connectionString);

            connection.Open();

        }





    }
}
