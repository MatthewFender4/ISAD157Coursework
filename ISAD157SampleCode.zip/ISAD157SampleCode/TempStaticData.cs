﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ISAD157SampleCode.Models;

namespace ISAD157SampleCode
{
   public class TempStaticData
    {

        public static PersonDetails userDetails = new PersonDetails()
        {
            userID=0, currentCity="Venice", gender = "F", homeTown="Cowdenbeath", relationship="single"
        };


        public static List<Messages> allMessages = new List<Messages>()
        {
            new Messages { MessageID=0, SenderID=3, ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="I give in"    },
            new Messages { MessageID=1, SenderID=2, ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="Don't give in" },
            new Messages { MessageID=2, SenderID=2, ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="I love chicken!"    },
            new Messages { MessageID=5, SenderID=3, ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="Divorce is near"    },
            new Messages { MessageID=9, SenderID=12, ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="Who cares who wins?" },
            new Messages { MessageID=10, SenderID=13, ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="Message me about the message"},
            new Messages { MessageID=19, SenderID=13, ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="Lockdown"    },
            new Messages { MessageID=109, SenderID=13,ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="Stay Smart"    },
            new Messages { MessageID=201, SenderID=0, ReceiverID=13, dt= new DateTime(2010,09,12),  MessageText="Save lives"    },
            new Messages { MessageID=204, SenderID=0, ReceiverID=12, dt= new DateTime(2010,09,12),  MessageText="Drink lots"},
            new Messages { MessageID=206, SenderID=0, ReceiverID=3, dt= new DateTime(2010,09,12),  MessageText="Picnics for all"    },
            new Messages { MessageID=290, SenderID=5, ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="Keep the beer flowing"    },
            new Messages { MessageID=320, SenderID=6, ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="I'm off to China"    },
            new Messages { MessageID=331, SenderID=7, ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="Dont hold your breath" },
            new Messages { MessageID=356, SenderID=8, ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="I'm still giving in"    },
            new Messages { MessageID=481, SenderID=10,ReceiverID=0, dt= new DateTime(2010,09,12),  MessageText="Designed on a Quantum Computer"    },
            new Messages { MessageID=520, SenderID=0, ReceiverID=6, dt= new DateTime(2010,09,12),  MessageText="What is the answer to life?"    },
            new Messages { MessageID=666, SenderID=0, ReceiverID=7, dt= new DateTime(2010,09,12),  MessageText="CV!"    },
            new Messages { MessageID=999, SenderID=0, ReceiverID=10, dt= new DateTime(2010,09,12),  MessageText="My morale is low!"    }
        };



        public static List<Person> thisPerson = new List<Person>()
        {
            new Person {userID= 0, firstName = "Jenny" , lastName = "Wren"},
            new Person {userID= 1, firstName = "Scott" , lastName = "Black"},
            new Person {userID= 2, firstName = "Matt" , lastName = "White"},
            new Person {userID= 3, firstName = "Jimmy" , lastName = "Green"},
            new Person {userID= 4, firstName = "Jim" , lastName = "TheChicken"},
            new Person {userID= 5, firstName = "Lenny" , lastName = "Henry"},
            new Person {userID= 6, firstName = "Sue" , lastName = "Smith"},
            new Person {userID= 7, firstName = "Walter" , lastName = "White"},
            new Person {userID= 8, firstName = "Penny" , lastName = "Black"},
            new Person {userID= 9, firstName = "Pat" , lastName = "Postman"},
            new Person {userID= 10, firstName = "John" , lastName = "Wayne"},
            new Person {userID= 11, firstName = "Wayne" , lastName = "Sleep"},
            new Person {userID= 12, firstName = "Claire" , lastName = "DeLune"},
            new Person {userID= 13, firstName = "Minnie" , lastName = "Driver"},
            new Person {userID= 14, firstName = "Robin" , lastName = "NoName"},
            new Person {userID= 15, firstName = "Batman" , lastName = "NoName2"},

        };
        

        public static List<PersonEducation> eduPlaces = new List<PersonEducation>()
        {
             new PersonEducation {userID= 0, placeName="Plymouth University", dateStarted=new DateTime(2010,09,12), dateFinished= new DateTime(2013,06,05)},
             new PersonEducation {userID= 0, placeName="Kirkcaldy High", dateStarted=new DateTime(1995,10,02), dateFinished= new DateTime(1998,07,13)},
             new PersonEducation {userID= 0, placeName="Cowdenbeath High", dateStarted=new DateTime(1993,01,05), dateFinished= new DateTime(1995,09,21)},
        };

        public static List<PersonWorkplaces> workPlaces = new List<PersonWorkplaces>()
        {
             new PersonWorkplaces {userID= 0, placeName="Cabinet Office", dateStarted=new DateTime(2020,09,12), dateFinished=  DateTime.Now},
             new PersonWorkplaces {userID= 0, placeName="Gooseberry Planet", dateStarted=new DateTime(2013,10,02), dateFinished= new DateTime(2020,07,13)},
             new PersonWorkplaces {userID= 0, placeName="Toys R Us", dateStarted=new DateTime(2011,01,05), dateFinished= new DateTime(2012,09,21)},
        };


    }
}
