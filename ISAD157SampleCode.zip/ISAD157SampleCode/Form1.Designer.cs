﻿namespace ISAD157SampleCode
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.LoginBtn = new System.Windows.Forms.Button();
            this.UserData = new System.Windows.Forms.TabPage();
            this.ClearAllBtn = new System.Windows.Forms.Button();
            this.UpdateBtn = new System.Windows.Forms.Button();
            this.SearchBtn = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.dataGridViewFriends = new System.Windows.Forms.DataGridView();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.dataGridViewMessages = new System.Windows.Forms.DataGridView();
            this.dataGridViewSchools = new System.Windows.Forms.DataGridView();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.dataGridViewWP = new System.Windows.Forms.DataGridView();
            this.dataGridViewUserDetails = new System.Windows.Forms.DataGridView();
            this.UserIDtextbox = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.RelationshipTextbox = new System.Windows.Forms.TextBox();
            this.GenderTextbox = new System.Windows.Forms.TextBox();
            this.CurrentCityTextbox = new System.Windows.Forms.TextBox();
            this.HomeTownTextbox = new System.Windows.Forms.TextBox();
            this.LastNametextbox = new System.Windows.Forms.TextBox();
            this.FirstNameTextbox = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.DeleteUserBtn = new System.Windows.Forms.Button();
            this.AddUserBtn = new System.Windows.Forms.Button();
            this.SelectUserBtn = new System.Windows.Forms.Button();
            this.LoadAllUserDataBtn = new System.Windows.Forms.Button();
            this.dataGridViewUsers = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label44 = new System.Windows.Forms.Label();
            this.UserIDLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SubmitEdit = new System.Windows.Forms.Button();
            this.EditRelationship = new System.Windows.Forms.TextBox();
            this.EditGender = new System.Windows.Forms.TextBox();
            this.EditCurrentCity = new System.Windows.Forms.TextBox();
            this.EditHomeTown = new System.Windows.Forms.TextBox();
            this.EditLastName = new System.Windows.Forms.TextBox();
            this.EditFirstName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.dataGridViewCurrentSchools = new System.Windows.Forms.DataGridView();
            this.dataGridViewCurrentWP = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.EduSubmitBtn = new System.Windows.Forms.Button();
            this.EduDeleteBtn = new System.Windows.Forms.Button();
            this.ToEduDatePicker = new System.Windows.Forms.DateTimePicker();
            this.FromEduDatePicker = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.EduText = new System.Windows.Forms.TextBox();
            this.WPSubmitBtn = new System.Windows.Forms.Button();
            this.WPorSchoolLabel = new System.Windows.Forms.Label();
            this.WPDeleteBtn = new System.Windows.Forms.Button();
            this.CancelAddUserBtn = new System.Windows.Forms.Button();
            this.ToWPDTPicker = new System.Windows.Forms.DateTimePicker();
            this.FromWPDTPicker = new System.Windows.Forms.DateTimePicker();
            this.UntilLabel = new System.Windows.Forms.Label();
            this.FromLabel = new System.Windows.Forms.Label();
            this.WPText = new System.Windows.Forms.TextBox();
            this.AddNewUserBtn = new System.Windows.Forms.Button();
            this.RelationshipText = new System.Windows.Forms.TextBox();
            this.GenderText = new System.Windows.Forms.TextBox();
            this.CurrentCityText = new System.Windows.Forms.TextBox();
            this.HomeTownText = new System.Windows.Forms.TextBox();
            this.LastNameText = new System.Windows.Forms.TextBox();
            this.FirstNameText = new System.Windows.Forms.TextBox();
            this.RelationshipLabel = new System.Windows.Forms.Label();
            this.GenderLabel = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.NumFriends = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.LoadDataTablesBtn1 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.FriendsLabel = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dataGridViewDBMessages = new System.Windows.Forms.DataGridView();
            this.dataGridViewDBFriends = new System.Windows.Forms.DataGridView();
            this.dataGridViewDBUserDetail = new System.Windows.Forms.DataGridView();
            this.dataGridViewDBUsers = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.LoadDataTablesBtn2 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.dataGridViewDBWorkplaceNames = new System.Windows.Forms.DataGridView();
            this.dataGridViewDBWorkplaces = new System.Windows.Forms.DataGridView();
            this.dataGridViewDBSchoolNames = new System.Windows.Forms.DataGridView();
            this.dataGridViewDBSchools = new System.Windows.Forms.DataGridView();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.mySqlConnection1 = new MySql.Data.MySqlClient.MySqlConnection();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.UserData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFriends)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMessages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSchools)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUserDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUsers)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCurrentSchools)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCurrentWP)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBMessages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBFriends)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBUserDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBUsers)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBWorkplaceNames)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBWorkplaces)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBSchoolNames)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBSchools)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.UserData);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(1, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1540, 893);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.LoginBtn);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1532, 867);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Login";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // LoginBtn
            // 
            this.LoginBtn.BackColor = System.Drawing.Color.Honeydew;
            this.LoginBtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.LoginBtn.FlatAppearance.BorderSize = 2;
            this.LoginBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginBtn.Location = new System.Drawing.Point(434, 306);
            this.LoginBtn.Name = "LoginBtn";
            this.LoginBtn.Size = new System.Drawing.Size(361, 116);
            this.LoginBtn.TabIndex = 1;
            this.LoginBtn.Text = "Connect to Database";
            this.LoginBtn.UseVisualStyleBackColor = false;
            this.LoginBtn.Click += new System.EventHandler(this.LoginBtn_Click);
            // 
            // UserData
            // 
            this.UserData.Controls.Add(this.ClearAllBtn);
            this.UserData.Controls.Add(this.UpdateBtn);
            this.UserData.Controls.Add(this.SearchBtn);
            this.UserData.Controls.Add(this.label41);
            this.UserData.Controls.Add(this.dataGridViewFriends);
            this.UserData.Controls.Add(this.label40);
            this.UserData.Controls.Add(this.label39);
            this.UserData.Controls.Add(this.dataGridViewMessages);
            this.UserData.Controls.Add(this.dataGridViewSchools);
            this.UserData.Controls.Add(this.label38);
            this.UserData.Controls.Add(this.label37);
            this.UserData.Controls.Add(this.dataGridViewWP);
            this.UserData.Controls.Add(this.dataGridViewUserDetails);
            this.UserData.Controls.Add(this.UserIDtextbox);
            this.UserData.Controls.Add(this.label36);
            this.UserData.Controls.Add(this.RelationshipTextbox);
            this.UserData.Controls.Add(this.GenderTextbox);
            this.UserData.Controls.Add(this.CurrentCityTextbox);
            this.UserData.Controls.Add(this.HomeTownTextbox);
            this.UserData.Controls.Add(this.LastNametextbox);
            this.UserData.Controls.Add(this.FirstNameTextbox);
            this.UserData.Controls.Add(this.label25);
            this.UserData.Controls.Add(this.label28);
            this.UserData.Controls.Add(this.label29);
            this.UserData.Controls.Add(this.label30);
            this.UserData.Controls.Add(this.label31);
            this.UserData.Controls.Add(this.label32);
            this.UserData.Controls.Add(this.label33);
            this.UserData.Controls.Add(this.label34);
            this.UserData.Controls.Add(this.label35);
            this.UserData.Controls.Add(this.DeleteUserBtn);
            this.UserData.Controls.Add(this.AddUserBtn);
            this.UserData.Controls.Add(this.SelectUserBtn);
            this.UserData.Controls.Add(this.LoadAllUserDataBtn);
            this.UserData.Controls.Add(this.dataGridViewUsers);
            this.UserData.Location = new System.Drawing.Point(4, 22);
            this.UserData.Name = "UserData";
            this.UserData.Padding = new System.Windows.Forms.Padding(3);
            this.UserData.Size = new System.Drawing.Size(1532, 867);
            this.UserData.TabIndex = 4;
            this.UserData.Text = "DB UserData";
            this.UserData.UseVisualStyleBackColor = true;
            // 
            // ClearAllBtn
            // 
            this.ClearAllBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClearAllBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearAllBtn.Location = new System.Drawing.Point(462, 798);
            this.ClearAllBtn.Name = "ClearAllBtn";
            this.ClearAllBtn.Size = new System.Drawing.Size(364, 37);
            this.ClearAllBtn.TabIndex = 80;
            this.ClearAllBtn.Text = "Clear Screen Data";
            this.ClearAllBtn.UseVisualStyleBackColor = false;
            this.ClearAllBtn.Click += new System.EventHandler(this.ClearAllBtn_Click);
            // 
            // UpdateBtn
            // 
            this.UpdateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.UpdateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateBtn.Location = new System.Drawing.Point(1143, 798);
            this.UpdateBtn.Name = "UpdateBtn";
            this.UpdateBtn.Size = new System.Drawing.Size(156, 37);
            this.UpdateBtn.TabIndex = 79;
            this.UpdateBtn.Text = "Update User";
            this.UpdateBtn.UseVisualStyleBackColor = false;
            this.UpdateBtn.Click += new System.EventHandler(this.UpdateBtn_Click);
            // 
            // SearchBtn
            // 
            this.SearchBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.SearchBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchBtn.Location = new System.Drawing.Point(670, 744);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(156, 37);
            this.SearchBtn.TabIndex = 78;
            this.SearchBtn.Text = "Search All";
            this.SearchBtn.UseVisualStyleBackColor = false;
            this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(25, 9);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(107, 25);
            this.label41.TabIndex = 77;
            this.label41.Text = "All Users";
            // 
            // dataGridViewFriends
            // 
            this.dataGridViewFriends.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFriends.Location = new System.Drawing.Point(864, 37);
            this.dataGridViewFriends.Name = "dataGridViewFriends";
            this.dataGridViewFriends.Size = new System.Drawing.Size(286, 678);
            this.dataGridViewFriends.TabIndex = 76;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(1166, 9);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(119, 25);
            this.label40.TabIndex = 75;
            this.label40.Text = "Messages";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(871, 9);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(91, 25);
            this.label39.TabIndex = 74;
            this.label39.Text = "Friends";
            // 
            // dataGridViewMessages
            // 
            this.dataGridViewMessages.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMessages.Location = new System.Drawing.Point(1171, 38);
            this.dataGridViewMessages.Name = "dataGridViewMessages";
            this.dataGridViewMessages.Size = new System.Drawing.Size(355, 678);
            this.dataGridViewMessages.TabIndex = 73;
            // 
            // dataGridViewSchools
            // 
            this.dataGridViewSchools.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSchools.Location = new System.Drawing.Point(421, 38);
            this.dataGridViewSchools.Name = "dataGridViewSchools";
            this.dataGridViewSchools.Size = new System.Drawing.Size(406, 153);
            this.dataGridViewSchools.TabIndex = 71;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(425, 204);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(135, 25);
            this.label38.TabIndex = 70;
            this.label38.Text = "Workplaces";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(425, 9);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(280, 25);
            this.label37.TabIndex = 69;
            this.label37.Text = "Schools  and Universities";
          
            // 
            // dataGridViewWP
            // 
            this.dataGridViewWP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewWP.Location = new System.Drawing.Point(420, 245);
            this.dataGridViewWP.Name = "dataGridViewWP";
            this.dataGridViewWP.Size = new System.Drawing.Size(407, 153);
            this.dataGridViewWP.TabIndex = 67;
            // 
            // dataGridViewUserDetails
            // 
            this.dataGridViewUserDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUserDetails.Location = new System.Drawing.Point(21, 846);
            this.dataGridViewUserDetails.Name = "dataGridViewUserDetails";
            this.dataGridViewUserDetails.Size = new System.Drawing.Size(51, 13);
            this.dataGridViewUserDetails.TabIndex = 66;
            // 
            // UserIDtextbox
            // 
            this.UserIDtextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserIDtextbox.Location = new System.Drawing.Point(559, 421);
            this.UserIDtextbox.Name = "UserIDtextbox";
            this.UserIDtextbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.UserIDtextbox.Size = new System.Drawing.Size(267, 29);
            this.UserIDtextbox.TabIndex = 65;
            this.UserIDtextbox.WordWrap = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(425, 425);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(72, 24);
            this.label36.TabIndex = 64;
            this.label36.Text = "UserID";
            // 
            // RelationshipTextbox
            // 
            this.RelationshipTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RelationshipTextbox.Location = new System.Drawing.Point(559, 680);
            this.RelationshipTextbox.Name = "RelationshipTextbox";
            this.RelationshipTextbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RelationshipTextbox.Size = new System.Drawing.Size(267, 29);
            this.RelationshipTextbox.TabIndex = 63;
            this.RelationshipTextbox.WordWrap = false;
            // 
            // GenderTextbox
            // 
            this.GenderTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderTextbox.Location = new System.Drawing.Point(559, 634);
            this.GenderTextbox.Name = "GenderTextbox";
            this.GenderTextbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.GenderTextbox.Size = new System.Drawing.Size(267, 29);
            this.GenderTextbox.TabIndex = 62;
            this.GenderTextbox.WordWrap = false;
            // 
            // CurrentCityTextbox
            // 
            this.CurrentCityTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CurrentCityTextbox.Location = new System.Drawing.Point(559, 587);
            this.CurrentCityTextbox.Name = "CurrentCityTextbox";
            this.CurrentCityTextbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.CurrentCityTextbox.Size = new System.Drawing.Size(267, 29);
            this.CurrentCityTextbox.TabIndex = 61;
            this.CurrentCityTextbox.WordWrap = false;
            // 
            // HomeTownTextbox
            // 
            this.HomeTownTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomeTownTextbox.Location = new System.Drawing.Point(559, 540);
            this.HomeTownTextbox.Name = "HomeTownTextbox";
            this.HomeTownTextbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.HomeTownTextbox.Size = new System.Drawing.Size(267, 29);
            this.HomeTownTextbox.TabIndex = 60;
            this.HomeTownTextbox.WordWrap = false;
            // 
            // LastNametextbox
            // 
            this.LastNametextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastNametextbox.Location = new System.Drawing.Point(559, 497);
            this.LastNametextbox.Name = "LastNametextbox";
            this.LastNametextbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.LastNametextbox.Size = new System.Drawing.Size(267, 29);
            this.LastNametextbox.TabIndex = 59;
            this.LastNametextbox.WordWrap = false;
            // 
            // FirstNameTextbox
            // 
            this.FirstNameTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstNameTextbox.Location = new System.Drawing.Point(559, 460);
            this.FirstNameTextbox.Name = "FirstNameTextbox";
            this.FirstNameTextbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.FirstNameTextbox.Size = new System.Drawing.Size(267, 29);
            this.FirstNameTextbox.TabIndex = 58;
            this.FirstNameTextbox.WordWrap = false;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label25.Location = new System.Drawing.Point(559, 680);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(0, 31);
            this.label25.TabIndex = 57;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label28.Location = new System.Drawing.Point(559, 631);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(0, 31);
            this.label28.TabIndex = 56;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(474, 716);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(0, 29);
            this.label29.TabIndex = 55;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(418, 680);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(125, 24);
            this.label30.TabIndex = 54;
            this.label30.Text = "Relationship";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(419, 631);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(80, 24);
            this.label31.TabIndex = 53;
            this.label31.Text = "Gender";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(419, 587);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(119, 24);
            this.label32.TabIndex = 52;
            this.label32.Text = "Current City";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(419, 542);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(124, 24);
            this.label33.TabIndex = 51;
            this.label33.Text = "Home Town";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(419, 497);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(108, 24);
            this.label34.TabIndex = 50;
            this.label34.Text = "Last Name";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(420, 460);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(111, 24);
            this.label35.TabIndex = 49;
            this.label35.Text = "First Name";
            // 
            // DeleteUserBtn
            // 
            this.DeleteUserBtn.BackColor = System.Drawing.Color.Red;
            this.DeleteUserBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteUserBtn.Location = new System.Drawing.Point(951, 798);
            this.DeleteUserBtn.Name = "DeleteUserBtn";
            this.DeleteUserBtn.Size = new System.Drawing.Size(156, 37);
            this.DeleteUserBtn.TabIndex = 48;
            this.DeleteUserBtn.Text = "Delete User";
            this.DeleteUserBtn.UseVisualStyleBackColor = false;
            this.DeleteUserBtn.Click += new System.EventHandler(this.DeleteUserBtn_Click);
            // 
            // AddUserBtn
            // 
            this.AddUserBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.AddUserBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddUserBtn.Location = new System.Drawing.Point(1335, 798);
            this.AddUserBtn.Name = "AddUserBtn";
            this.AddUserBtn.Size = new System.Drawing.Size(156, 37);
            this.AddUserBtn.TabIndex = 47;
            this.AddUserBtn.Text = "Add User";
            this.AddUserBtn.UseVisualStyleBackColor = false;
            this.AddUserBtn.Click += new System.EventHandler(this.AddUserBtn_Click);
            // 
            // SelectUserBtn
            // 
            this.SelectUserBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.SelectUserBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectUserBtn.Location = new System.Drawing.Point(462, 744);
            this.SelectUserBtn.Name = "SelectUserBtn";
            this.SelectUserBtn.Size = new System.Drawing.Size(156, 37);
            this.SelectUserBtn.TabIndex = 46;
            this.SelectUserBtn.Text = "Select  User";
            this.SelectUserBtn.UseVisualStyleBackColor = false;
            this.SelectUserBtn.Click += new System.EventHandler(this.SelectUserBtn_Click);
            // 
            // LoadAllUserDataBtn
            // 
            this.LoadAllUserDataBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.LoadAllUserDataBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoadAllUserDataBtn.Location = new System.Drawing.Point(21, 798);
            this.LoadAllUserDataBtn.Name = "LoadAllUserDataBtn";
            this.LoadAllUserDataBtn.Size = new System.Drawing.Size(385, 37);
            this.LoadAllUserDataBtn.TabIndex = 45;
            this.LoadAllUserDataBtn.Text = "Load All Users";
            this.LoadAllUserDataBtn.UseVisualStyleBackColor = false;
            this.LoadAllUserDataBtn.Click += new System.EventHandler(this.LoadAllUserDataBtn_Click);
            // 
            // dataGridViewUsers
            // 
            this.dataGridViewUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUsers.Location = new System.Drawing.Point(21, 37);
            this.dataGridViewUsers.MultiSelect = false;
            this.dataGridViewUsers.Name = "dataGridViewUsers";
            this.dataGridViewUsers.ReadOnly = true;
            this.dataGridViewUsers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewUsers.Size = new System.Drawing.Size(385, 744);
            this.dataGridViewUsers.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label44);
            this.tabPage2.Controls.Add(this.UserIDLabel);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.SubmitEdit);
            this.tabPage2.Controls.Add(this.EditRelationship);
            this.tabPage2.Controls.Add(this.EditGender);
            this.tabPage2.Controls.Add(this.EditCurrentCity);
            this.tabPage2.Controls.Add(this.EditHomeTown);
            this.tabPage2.Controls.Add(this.EditLastName);
            this.tabPage2.Controls.Add(this.EditFirstName);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Controls.Add(this.label42);
            this.tabPage2.Controls.Add(this.label43);
            this.tabPage2.Controls.Add(this.dataGridViewCurrentSchools);
            this.tabPage2.Controls.Add(this.dataGridViewCurrentWP);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.EduSubmitBtn);
            this.tabPage2.Controls.Add(this.EduDeleteBtn);
            this.tabPage2.Controls.Add(this.ToEduDatePicker);
            this.tabPage2.Controls.Add(this.FromEduDatePicker);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.EduText);
            this.tabPage2.Controls.Add(this.WPSubmitBtn);
            this.tabPage2.Controls.Add(this.WPorSchoolLabel);
            this.tabPage2.Controls.Add(this.WPDeleteBtn);
            this.tabPage2.Controls.Add(this.CancelAddUserBtn);
            this.tabPage2.Controls.Add(this.ToWPDTPicker);
            this.tabPage2.Controls.Add(this.FromWPDTPicker);
            this.tabPage2.Controls.Add(this.UntilLabel);
            this.tabPage2.Controls.Add(this.FromLabel);
            this.tabPage2.Controls.Add(this.WPText);
            this.tabPage2.Controls.Add(this.AddNewUserBtn);
            this.tabPage2.Controls.Add(this.RelationshipText);
            this.tabPage2.Controls.Add(this.GenderText);
            this.tabPage2.Controls.Add(this.CurrentCityText);
            this.tabPage2.Controls.Add(this.HomeTownText);
            this.tabPage2.Controls.Add(this.LastNameText);
            this.tabPage2.Controls.Add(this.FirstNameText);
            this.tabPage2.Controls.Add(this.RelationshipLabel);
            this.tabPage2.Controls.Add(this.GenderLabel);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.NumFriends);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tabPage2.Size = new System.Drawing.Size(1532, 867);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Add or Edit User";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(36, 46);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(93, 29);
            this.label44.TabIndex = 73;
            this.label44.Text = "UserID";
            // 
            // UserIDLabel
            // 
            this.UserIDLabel.AutoSize = true;
            this.UserIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserIDLabel.Location = new System.Drawing.Point(242, 46);
            this.UserIDLabel.Name = "UserIDLabel";
            this.UserIDLabel.Size = new System.Drawing.Size(38, 29);
            this.UserIDLabel.TabIndex = 72;
            this.UserIDLabel.Text = "ID";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(36, 428);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(407, 54);
            this.button1.TabIndex = 71;
            this.button1.Text = "CANCEL ";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // SubmitEdit
            // 
            this.SubmitEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.SubmitEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitEdit.Location = new System.Drawing.Point(35, 366);
            this.SubmitEdit.Name = "SubmitEdit";
            this.SubmitEdit.Size = new System.Drawing.Size(408, 56);
            this.SubmitEdit.TabIndex = 70;
            this.SubmitEdit.Text = "SUBMIT EDIT";
            this.SubmitEdit.UseVisualStyleBackColor = false;
            this.SubmitEdit.Click += new System.EventHandler(this.SubmitEdit_Click);
            // 
            // EditRelationship
            // 
            this.EditRelationship.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditRelationship.Location = new System.Drawing.Point(242, 311);
            this.EditRelationship.Name = "EditRelationship";
            this.EditRelationship.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.EditRelationship.Size = new System.Drawing.Size(201, 31);
            this.EditRelationship.TabIndex = 69;
            this.EditRelationship.WordWrap = false;
            // 
            // EditGender
            // 
            this.EditGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditGender.Location = new System.Drawing.Point(242, 265);
            this.EditGender.Name = "EditGender";
            this.EditGender.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.EditGender.Size = new System.Drawing.Size(201, 31);
            this.EditGender.TabIndex = 68;
            this.EditGender.WordWrap = false;
            // 
            // EditCurrentCity
            // 
            this.EditCurrentCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditCurrentCity.Location = new System.Drawing.Point(242, 218);
            this.EditCurrentCity.Name = "EditCurrentCity";
            this.EditCurrentCity.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.EditCurrentCity.Size = new System.Drawing.Size(201, 31);
            this.EditCurrentCity.TabIndex = 67;
            this.EditCurrentCity.WordWrap = false;
            // 
            // EditHomeTown
            // 
            this.EditHomeTown.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditHomeTown.Location = new System.Drawing.Point(242, 171);
            this.EditHomeTown.Name = "EditHomeTown";
            this.EditHomeTown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.EditHomeTown.Size = new System.Drawing.Size(201, 31);
            this.EditHomeTown.TabIndex = 66;
            this.EditHomeTown.WordWrap = false;
            // 
            // EditLastName
            // 
            this.EditLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditLastName.Location = new System.Drawing.Point(242, 128);
            this.EditLastName.Name = "EditLastName";
            this.EditLastName.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.EditLastName.Size = new System.Drawing.Size(201, 31);
            this.EditLastName.TabIndex = 65;
            this.EditLastName.WordWrap = false;
            // 
            // EditFirstName
            // 
            this.EditFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditFirstName.Location = new System.Drawing.Point(242, 91);
            this.EditFirstName.Name = "EditFirstName";
            this.EditFirstName.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.EditFirstName.Size = new System.Drawing.Size(201, 31);
            this.EditFirstName.TabIndex = 64;
            this.EditFirstName.WordWrap = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label6.Location = new System.Drawing.Point(242, 311);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 31);
            this.label6.TabIndex = 63;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label21.Location = new System.Drawing.Point(242, 262);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(0, 31);
            this.label21.TabIndex = 62;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(36, 331);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(0, 29);
            this.label22.TabIndex = 61;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(36, 314);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(159, 29);
            this.label23.TabIndex = 60;
            this.label23.Text = "Relationship";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(36, 262);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(100, 29);
            this.label24.TabIndex = 59;
            this.label24.Text = "Gender";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(36, 218);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(150, 29);
            this.label26.TabIndex = 58;
            this.label26.Text = "Current City";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(36, 173);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(154, 29);
            this.label27.TabIndex = 57;
            this.label27.Text = "Home Town";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(36, 128);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(137, 29);
            this.label42.TabIndex = 56;
            this.label42.Text = "Last Name";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(36, 91);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(141, 29);
            this.label43.TabIndex = 55;
            this.label43.Text = "First Name";
            // 
            // dataGridViewCurrentSchools
            // 
            this.dataGridViewCurrentSchools.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCurrentSchools.Location = new System.Drawing.Point(1022, 401);
            this.dataGridViewCurrentSchools.Name = "dataGridViewCurrentSchools";
            this.dataGridViewCurrentSchools.Size = new System.Drawing.Size(478, 150);
            this.dataGridViewCurrentSchools.TabIndex = 54;
            // 
            // dataGridViewCurrentWP
            // 
            this.dataGridViewCurrentWP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCurrentWP.Location = new System.Drawing.Point(1022, 56);
            this.dataGridViewCurrentWP.Name = "dataGridViewCurrentWP";
            this.dataGridViewCurrentWP.Size = new System.Drawing.Size(478, 150);
            this.dataGridViewCurrentWP.TabIndex = 53;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1012, 367);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(442, 31);
            this.label8.TabIndex = 52;
            this.label8.Text = "Current Schools and Universities";
            // 
            // EduSubmitBtn
            // 
            this.EduSubmitBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.EduSubmitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EduSubmitBtn.Location = new System.Drawing.Point(1364, 626);
            this.EduSubmitBtn.Name = "EduSubmitBtn";
            this.EduSubmitBtn.Size = new System.Drawing.Size(150, 37);
            this.EduSubmitBtn.TabIndex = 51;
            this.EduSubmitBtn.Text = "Submit";
            this.EduSubmitBtn.UseVisualStyleBackColor = false;
            // 
            // EduDeleteBtn
            // 
            this.EduDeleteBtn.BackColor = System.Drawing.Color.Red;
            this.EduDeleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EduDeleteBtn.Location = new System.Drawing.Point(1364, 564);
            this.EduDeleteBtn.Name = "EduDeleteBtn";
            this.EduDeleteBtn.Size = new System.Drawing.Size(150, 41);
            this.EduDeleteBtn.TabIndex = 50;
            this.EduDeleteBtn.Text = "Delete ";
            this.EduDeleteBtn.UseVisualStyleBackColor = false;
            // 
            // ToEduDatePicker
            // 
            this.ToEduDatePicker.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToEduDatePicker.Location = new System.Drawing.Point(1088, 643);
            this.ToEduDatePicker.Name = "ToEduDatePicker";
            this.ToEduDatePicker.Size = new System.Drawing.Size(230, 20);
            this.ToEduDatePicker.TabIndex = 49;
            // 
            // FromEduDatePicker
            // 
            this.FromEduDatePicker.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FromEduDatePicker.Location = new System.Drawing.Point(1087, 617);
            this.FromEduDatePicker.Name = "FromEduDatePicker";
            this.FromEduDatePicker.Size = new System.Drawing.Size(230, 20);
            this.FromEduDatePicker.TabIndex = 48;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(1012, 639);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(51, 24);
            this.label16.TabIndex = 47;
            this.label16.Text = "Until";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(1012, 613);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(59, 24);
            this.label17.TabIndex = 46;
            this.label17.Text = "From";
            // 
            // EduText
            // 
            this.EduText.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EduText.Location = new System.Drawing.Point(1012, 570);
            this.EduText.Name = "EduText";
            this.EduText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.EduText.Size = new System.Drawing.Size(318, 29);
            this.EduText.TabIndex = 45;
            this.EduText.Text = "Current Schools and Universities";
            this.EduText.WordWrap = false;
            // 
            // WPSubmitBtn
            // 
            this.WPSubmitBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.WPSubmitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WPSubmitBtn.Location = new System.Drawing.Point(1364, 296);
            this.WPSubmitBtn.Name = "WPSubmitBtn";
            this.WPSubmitBtn.Size = new System.Drawing.Size(150, 37);
            this.WPSubmitBtn.TabIndex = 44;
            this.WPSubmitBtn.Text = "Submit";
            this.WPSubmitBtn.UseVisualStyleBackColor = false;
            // 
            // WPorSchoolLabel
            // 
            this.WPorSchoolLabel.AutoSize = true;
            this.WPorSchoolLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WPorSchoolLabel.Location = new System.Drawing.Point(1022, 484);
            this.WPorSchoolLabel.Name = "WPorSchoolLabel";
            this.WPorSchoolLabel.Size = new System.Drawing.Size(0, 24);
            this.WPorSchoolLabel.TabIndex = 39;
            this.WPorSchoolLabel.Click += new System.EventHandler(this.label15_Click_1);
            // 
            // WPDeleteBtn
            // 
            this.WPDeleteBtn.BackColor = System.Drawing.Color.Red;
            this.WPDeleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WPDeleteBtn.Location = new System.Drawing.Point(1364, 240);
            this.WPDeleteBtn.Name = "WPDeleteBtn";
            this.WPDeleteBtn.Size = new System.Drawing.Size(150, 41);
            this.WPDeleteBtn.TabIndex = 38;
            this.WPDeleteBtn.Text = "Delete ";
            this.WPDeleteBtn.UseVisualStyleBackColor = false;
            // 
            // CancelAddUserBtn
            // 
            this.CancelAddUserBtn.BackColor = System.Drawing.Color.Red;
            this.CancelAddUserBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelAddUserBtn.Location = new System.Drawing.Point(565, 427);
            this.CancelAddUserBtn.Name = "CancelAddUserBtn";
            this.CancelAddUserBtn.Size = new System.Drawing.Size(407, 54);
            this.CancelAddUserBtn.TabIndex = 37;
            this.CancelAddUserBtn.Text = "CANCEL ";
            this.CancelAddUserBtn.UseVisualStyleBackColor = false;
            // 
            // ToWPDTPicker
            // 
            this.ToWPDTPicker.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToWPDTPicker.Location = new System.Drawing.Point(1101, 313);
            this.ToWPDTPicker.Name = "ToWPDTPicker";
            this.ToWPDTPicker.Size = new System.Drawing.Size(230, 20);
            this.ToWPDTPicker.TabIndex = 36;
            // 
            // FromWPDTPicker
            // 
            this.FromWPDTPicker.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FromWPDTPicker.Location = new System.Drawing.Point(1100, 287);
            this.FromWPDTPicker.Name = "FromWPDTPicker";
            this.FromWPDTPicker.Size = new System.Drawing.Size(230, 20);
            this.FromWPDTPicker.TabIndex = 35;
            // 
            // UntilLabel
            // 
            this.UntilLabel.AutoSize = true;
            this.UntilLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UntilLabel.Location = new System.Drawing.Point(1025, 309);
            this.UntilLabel.Name = "UntilLabel";
            this.UntilLabel.Size = new System.Drawing.Size(51, 24);
            this.UntilLabel.TabIndex = 34;
            this.UntilLabel.Text = "Until";
            this.UntilLabel.Click += new System.EventHandler(this.label17_Click);
            // 
            // FromLabel
            // 
            this.FromLabel.AutoSize = true;
            this.FromLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FromLabel.Location = new System.Drawing.Point(1025, 283);
            this.FromLabel.Name = "FromLabel";
            this.FromLabel.Size = new System.Drawing.Size(59, 24);
            this.FromLabel.TabIndex = 33;
            this.FromLabel.Text = "From";
            this.FromLabel.Click += new System.EventHandler(this.label16_Click);
            // 
            // WPText
            // 
            this.WPText.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WPText.Location = new System.Drawing.Point(1025, 240);
            this.WPText.Name = "WPText";
            this.WPText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.WPText.Size = new System.Drawing.Size(306, 29);
            this.WPText.TabIndex = 32;
            this.WPText.Text = "Workplace Name";
            this.WPText.WordWrap = false;
            // 
            // AddNewUserBtn
            // 
            this.AddNewUserBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.AddNewUserBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewUserBtn.Location = new System.Drawing.Point(564, 365);
            this.AddNewUserBtn.Name = "AddNewUserBtn";
            this.AddNewUserBtn.Size = new System.Drawing.Size(408, 56);
            this.AddNewUserBtn.TabIndex = 30;
            this.AddNewUserBtn.Text = "Add New User";
            this.AddNewUserBtn.UseVisualStyleBackColor = false;
            this.AddNewUserBtn.Click += new System.EventHandler(this.AddNewUserBtn_Click);
            // 
            // RelationshipText
            // 
            this.RelationshipText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RelationshipText.Location = new System.Drawing.Point(771, 310);
            this.RelationshipText.Name = "RelationshipText";
            this.RelationshipText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RelationshipText.Size = new System.Drawing.Size(201, 31);
            this.RelationshipText.TabIndex = 27;
            this.RelationshipText.WordWrap = false;
            // 
            // GenderText
            // 
            this.GenderText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderText.Location = new System.Drawing.Point(771, 264);
            this.GenderText.Name = "GenderText";
            this.GenderText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.GenderText.Size = new System.Drawing.Size(201, 31);
            this.GenderText.TabIndex = 26;
            this.GenderText.WordWrap = false;
            // 
            // CurrentCityText
            // 
            this.CurrentCityText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CurrentCityText.Location = new System.Drawing.Point(771, 217);
            this.CurrentCityText.Name = "CurrentCityText";
            this.CurrentCityText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.CurrentCityText.Size = new System.Drawing.Size(201, 31);
            this.CurrentCityText.TabIndex = 25;
            this.CurrentCityText.WordWrap = false;
            // 
            // HomeTownText
            // 
            this.HomeTownText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomeTownText.Location = new System.Drawing.Point(771, 170);
            this.HomeTownText.Name = "HomeTownText";
            this.HomeTownText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.HomeTownText.Size = new System.Drawing.Size(201, 31);
            this.HomeTownText.TabIndex = 24;
            this.HomeTownText.WordWrap = false;
            // 
            // LastNameText
            // 
            this.LastNameText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastNameText.Location = new System.Drawing.Point(771, 127);
            this.LastNameText.Name = "LastNameText";
            this.LastNameText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.LastNameText.Size = new System.Drawing.Size(201, 31);
            this.LastNameText.TabIndex = 23;
            this.LastNameText.WordWrap = false;
            // 
            // FirstNameText
            // 
            this.FirstNameText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstNameText.Location = new System.Drawing.Point(771, 90);
            this.FirstNameText.Name = "FirstNameText";
            this.FirstNameText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.FirstNameText.Size = new System.Drawing.Size(201, 31);
            this.FirstNameText.TabIndex = 22;
            this.FirstNameText.WordWrap = false;
            // 
            // RelationshipLabel
            // 
            this.RelationshipLabel.AutoSize = true;
            this.RelationshipLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RelationshipLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.RelationshipLabel.Location = new System.Drawing.Point(771, 310);
            this.RelationshipLabel.Name = "RelationshipLabel";
            this.RelationshipLabel.Size = new System.Drawing.Size(0, 31);
            this.RelationshipLabel.TabIndex = 21;
            // 
            // GenderLabel
            // 
            this.GenderLabel.AutoSize = true;
            this.GenderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.GenderLabel.Location = new System.Drawing.Point(771, 261);
            this.GenderLabel.Name = "GenderLabel";
            this.GenderLabel.Size = new System.Drawing.Size(0, 31);
            this.GenderLabel.TabIndex = 20;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(565, 330);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 29);
            this.label12.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(565, 313);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(159, 29);
            this.label7.TabIndex = 16;
            this.label7.Text = "Relationship";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(565, 261);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 29);
            this.label11.TabIndex = 15;
            this.label11.Text = "Gender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(565, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 29);
            this.label4.TabIndex = 14;
            this.label4.Text = "Current City";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(565, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 29);
            this.label3.TabIndex = 13;
            this.label3.Text = "Home Town";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(1014, 22);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(275, 31);
            this.label10.TabIndex = 9;
            this.label10.Text = "Current WorkPlaces";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // NumFriends
            // 
            this.NumFriends.AutoSize = true;
            this.NumFriends.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumFriends.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.NumFriends.Location = new System.Drawing.Point(399, 504);
            this.NumFriends.Name = "NumFriends";
            this.NumFriends.Size = new System.Drawing.Size(0, 31);
            this.NumFriends.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(80, 504);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 31);
            this.label5.TabIndex = 4;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(565, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(565, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.LoadDataTablesBtn1);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.FriendsLabel);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.label9);
            this.tabPage5.Controls.Add(this.dataGridViewDBMessages);
            this.tabPage5.Controls.Add(this.dataGridViewDBFriends);
            this.tabPage5.Controls.Add(this.dataGridViewDBUserDetail);
            this.tabPage5.Controls.Add(this.dataGridViewDBUsers);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1532, 867);
            this.tabPage5.TabIndex = 5;
            this.tabPage5.Text = "DB Tables 1";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // LoadDataTablesBtn1
            // 
            this.LoadDataTablesBtn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.LoadDataTablesBtn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoadDataTablesBtn1.Location = new System.Drawing.Point(687, 762);
            this.LoadDataTablesBtn1.Name = "LoadDataTablesBtn1";
            this.LoadDataTablesBtn1.Size = new System.Drawing.Size(217, 37);
            this.LoadDataTablesBtn1.TabIndex = 46;
            this.LoadDataTablesBtn1.Text = "Load Data Tables";
            this.LoadDataTablesBtn1.UseVisualStyleBackColor = false;
            this.LoadDataTablesBtn1.Click += new System.EventHandler(this.LoadDataTablesBtn1_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(1120, 7);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(122, 24);
            this.label15.TabIndex = 7;
            this.label15.Text = "All Messages";
            // 
            // FriendsLabel
            // 
            this.FriendsLabel.AutoSize = true;
            this.FriendsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FriendsLabel.Location = new System.Drawing.Point(826, 7);
            this.FriendsLabel.Name = "FriendsLabel";
            this.FriendsLabel.Size = new System.Drawing.Size(100, 24);
            this.FriendsLabel.TabIndex = 6;
            this.FriendsLabel.Text = "All Friends";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(404, 7);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(135, 24);
            this.label13.TabIndex = 5;
            this.label13.Text = "All User Details";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(15, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 24);
            this.label9.TabIndex = 4;
            this.label9.Text = "All Users";
            // 
            // dataGridViewDBMessages
            // 
            this.dataGridViewDBMessages.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDBMessages.Location = new System.Drawing.Point(1114, 34);
            this.dataGridViewDBMessages.Name = "dataGridViewDBMessages";
            this.dataGridViewDBMessages.Size = new System.Drawing.Size(378, 692);
            this.dataGridViewDBMessages.TabIndex = 3;
            // 
            // dataGridViewDBFriends
            // 
            this.dataGridViewDBFriends.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDBFriends.Location = new System.Drawing.Point(823, 34);
            this.dataGridViewDBFriends.Name = "dataGridViewDBFriends";
            this.dataGridViewDBFriends.Size = new System.Drawing.Size(258, 692);
            this.dataGridViewDBFriends.TabIndex = 2;
            // 
            // dataGridViewDBUserDetail
            // 
            this.dataGridViewDBUserDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDBUserDetail.Location = new System.Drawing.Point(408, 34);
            this.dataGridViewDBUserDetail.Name = "dataGridViewDBUserDetail";
            this.dataGridViewDBUserDetail.Size = new System.Drawing.Size(378, 692);
            this.dataGridViewDBUserDetail.TabIndex = 1;
            // 
            // dataGridViewDBUsers
            // 
            this.dataGridViewDBUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDBUsers.Location = new System.Drawing.Point(19, 34);
            this.dataGridViewDBUsers.Name = "dataGridViewDBUsers";
            this.dataGridViewDBUsers.Size = new System.Drawing.Size(339, 692);
            this.dataGridViewDBUsers.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.LoadDataTablesBtn2);
            this.tabPage6.Controls.Add(this.label14);
            this.tabPage6.Controls.Add(this.label18);
            this.tabPage6.Controls.Add(this.label19);
            this.tabPage6.Controls.Add(this.label20);
            this.tabPage6.Controls.Add(this.dataGridViewDBWorkplaceNames);
            this.tabPage6.Controls.Add(this.dataGridViewDBWorkplaces);
            this.tabPage6.Controls.Add(this.dataGridViewDBSchoolNames);
            this.tabPage6.Controls.Add(this.dataGridViewDBSchools);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1532, 867);
            this.tabPage6.TabIndex = 6;
            this.tabPage6.Text = "DB Tables 2";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // LoadDataTablesBtn2
            // 
            this.LoadDataTablesBtn2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.LoadDataTablesBtn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoadDataTablesBtn2.Location = new System.Drawing.Point(705, 791);
            this.LoadDataTablesBtn2.Name = "LoadDataTablesBtn2";
            this.LoadDataTablesBtn2.Size = new System.Drawing.Size(217, 37);
            this.LoadDataTablesBtn2.TabIndex = 55;
            this.LoadDataTablesBtn2.Text = "Load Data Tables";
            this.LoadDataTablesBtn2.UseVisualStyleBackColor = false;
            this.LoadDataTablesBtn2.Click += new System.EventHandler(this.LoadDataTablesBtn2_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(1138, 36);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(165, 24);
            this.label14.TabIndex = 54;
            this.label14.Text = "Workplace Names";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(844, 36);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(109, 24);
            this.label18.TabIndex = 53;
            this.label18.Text = "Workplaces";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(422, 36);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(134, 24);
            this.label19.TabIndex = 52;
            this.label19.Text = "School Names";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(33, 36);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(215, 24);
            this.label20.TabIndex = 51;
            this.label20.Text = "Schools and Universities";
            // 
            // dataGridViewDBWorkplaceNames
            // 
            this.dataGridViewDBWorkplaceNames.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDBWorkplaceNames.Location = new System.Drawing.Point(1132, 63);
            this.dataGridViewDBWorkplaceNames.Name = "dataGridViewDBWorkplaceNames";
            this.dataGridViewDBWorkplaceNames.Size = new System.Drawing.Size(378, 692);
            this.dataGridViewDBWorkplaceNames.TabIndex = 50;
            // 
            // dataGridViewDBWorkplaces
            // 
            this.dataGridViewDBWorkplaces.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDBWorkplaces.Location = new System.Drawing.Point(841, 63);
            this.dataGridViewDBWorkplaces.Name = "dataGridViewDBWorkplaces";
            this.dataGridViewDBWorkplaces.Size = new System.Drawing.Size(258, 692);
            this.dataGridViewDBWorkplaces.TabIndex = 49;
            // 
            // dataGridViewDBSchoolNames
            // 
            this.dataGridViewDBSchoolNames.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDBSchoolNames.Location = new System.Drawing.Point(426, 63);
            this.dataGridViewDBSchoolNames.Name = "dataGridViewDBSchoolNames";
            this.dataGridViewDBSchoolNames.Size = new System.Drawing.Size(378, 692);
            this.dataGridViewDBSchoolNames.TabIndex = 48;
            // 
            // dataGridViewDBSchools
            // 
            this.dataGridViewDBSchools.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDBSchools.Location = new System.Drawing.Point(37, 63);
            this.dataGridViewDBSchools.Name = "dataGridViewDBSchools";
            this.dataGridViewDBSchools.Size = new System.Drawing.Size(339, 692);
            this.dataGridViewDBSchools.TabIndex = 47;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(1543, 896);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "ISAD157SampleCode";
           
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.UserData.ResumeLayout(false);
            this.UserData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFriends)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMessages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSchools)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUserDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUsers)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCurrentSchools)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCurrentWP)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBMessages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBFriends)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBUserDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBUsers)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBWorkplaceNames)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBWorkplaces)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBSchoolNames)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDBSchools)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button LoginBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label NumFriends;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label RelationshipLabel;
        private System.Windows.Forms.Label GenderLabel;
        private System.Windows.Forms.TextBox FirstNameText;
        private System.Windows.Forms.TextBox LastNameText;
        private System.Windows.Forms.TextBox CurrentCityText;
        private System.Windows.Forms.TextBox HomeTownText;
        private System.Windows.Forms.TextBox RelationshipText;
        private System.Windows.Forms.TextBox GenderText;
        private System.Windows.Forms.Button AddNewUserBtn;
        private System.Windows.Forms.Label FromLabel;
        private System.Windows.Forms.TextBox WPText;
        private System.Windows.Forms.Label UntilLabel;
        private System.Windows.Forms.DateTimePicker FromWPDTPicker;
        private System.Windows.Forms.DateTimePicker ToWPDTPicker;
        private System.Windows.Forms.Button CancelAddUserBtn;
        private System.Windows.Forms.Label WPorSchoolLabel;
        private System.Windows.Forms.Button WPDeleteBtn;
        private System.Windows.Forms.Button WPSubmitBtn;
        private System.Windows.Forms.Button EduSubmitBtn;
        private System.Windows.Forms.Button EduDeleteBtn;
        private System.Windows.Forms.DateTimePicker ToEduDatePicker;
        private System.Windows.Forms.DateTimePicker FromEduDatePicker;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox EduText;
        private System.Windows.Forms.ToolTip toolTip1;
        private MySql.Data.MySqlClient.MySqlConnection mySqlConnection1;
        private System.Windows.Forms.TabPage UserData;
        private System.Windows.Forms.DataGridView dataGridViewUsers;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataGridView dataGridViewDBUsers;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button DeleteUserBtn;
        private System.Windows.Forms.Button AddUserBtn;
        private System.Windows.Forms.Button SelectUserBtn;
        private System.Windows.Forms.Button LoadAllUserDataBtn;
        private System.Windows.Forms.TextBox UserIDtextbox;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox RelationshipTextbox;
        private System.Windows.Forms.TextBox GenderTextbox;
        private System.Windows.Forms.TextBox CurrentCityTextbox;
        private System.Windows.Forms.TextBox HomeTownTextbox;
        private System.Windows.Forms.TextBox LastNametextbox;
        private System.Windows.Forms.TextBox FirstNameTextbox;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.DataGridView dataGridViewUserDetails;
        private System.Windows.Forms.DataGridView dataGridViewWP;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.DataGridView dataGridViewSchools;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.DataGridView dataGridViewMessages;
        private System.Windows.Forms.DataGridView dataGridViewFriends;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button UpdateBtn;
        private System.Windows.Forms.Button SearchBtn;
        private System.Windows.Forms.DataGridView dataGridViewCurrentSchools;
        private System.Windows.Forms.DataGridView dataGridViewCurrentWP;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button LoadDataTablesBtn1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label FriendsLabel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dataGridViewDBMessages;
        private System.Windows.Forms.DataGridView dataGridViewDBFriends;
        private System.Windows.Forms.DataGridView dataGridViewDBUserDetail;
        private System.Windows.Forms.Button LoadDataTablesBtn2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DataGridView dataGridViewDBWorkplaceNames;
        private System.Windows.Forms.DataGridView dataGridViewDBWorkplaces;
        private System.Windows.Forms.DataGridView dataGridViewDBSchoolNames;
        private System.Windows.Forms.DataGridView dataGridViewDBSchools;
        private System.Windows.Forms.Button ClearAllBtn;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label UserIDLabel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button SubmitEdit;
        private System.Windows.Forms.TextBox EditRelationship;
        private System.Windows.Forms.TextBox EditGender;
        private System.Windows.Forms.TextBox EditCurrentCity;
        private System.Windows.Forms.TextBox EditHomeTown;
        private System.Windows.Forms.TextBox EditLastName;
        private System.Windows.Forms.TextBox EditFirstName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
    }
}

